
public class Communication {
	private String num1;
	private String num2;
	private int day;
	private int month;
	private int year;
	

	public String getNum1() {
		return num1;
	}


	public void setNum1(String num1) {
		this.num1 = num1;
	}


	public String getNum2() {
		return num2;
	}


	public void setNum2(String num2) {
		this.num2 = num2;
	}


	public int getDay() {
		return day;
	}


	public void setDay(int day) {
		this.day = day;
	}


	public int getMonth() {
		return month;
	}


	public void setMonth(int month) {
		this.month = month;
	}


	public int getYear() {
		return year;
	}


	public void setYear(int year) {
		this.year = year;
	}


	public Communication(String num1, String num2, int day, int month, int year) {
		super();
		this.num1 = num1;
		this.num2 = num2;
		this.day = day;
		this.month = month;
		this.year = year;
	}
	 
	
	

}
