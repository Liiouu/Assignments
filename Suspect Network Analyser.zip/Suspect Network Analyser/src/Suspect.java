import java.util.*;


public class Suspect {
	private String name;
	private String codename;
	private String city;
	private ArrayList<String> numbers = new ArrayList<>();
	private ArrayList<Suspect> Partners = new ArrayList<>();
	
	public Suspect(String name, String codename, String city)
	{
		this.name = name;
		this.codename = codename;
		this.city = city;
	}
	
	public ArrayList<Suspect> suggestedPartners()
	{
		ArrayList<Suspect> suggestedSuspects = new ArrayList<>();
		
		for(Suspect partner : this.Partners)
		{
			for(Suspect potentialPartner : partner.Partners)
			{
				if((!this.Partners.contains(potentialPartner)) && (!suggestedSuspects.contains(potentialPartner)) && (!this.name.equals(potentialPartner.name)))
					suggestedSuspects.add(potentialPartner);
			}
		}
		suggestedSuspects.sort(Comparator.comparing(Suspect::getName));
		
		return suggestedSuspects;
	}
	
	public void addPartner(Suspect S)
	{
		if(!this.Partners.contains(S))
		{
			Partners.add(S);
		}
		
	}
	
	
	public boolean isConnectedTo(Suspect aSuspect)
	{
		return Partners.contains(aSuspect);
	}
	
	public ArrayList<Suspect> getCommonPartners(Suspect aSuspect)
	{
		ArrayList<Suspect> commonPartners = new ArrayList<>();
		for (Suspect partner : this.Partners) 
		{
			if (aSuspect.Partners.contains(partner)) {
				commonPartners.add(partner);
			}
		}
		return commonPartners;
	}
	
	public void printInfo()
	{
		System.out.println();
		System.out.println("Suspect: " + name);
		System.out.println("Possible Partners:");
		if(Partners.isEmpty())
		{
			System.out.println("No partners found.");
		}
		else 
		{
			for(Suspect s : Partners)
			{
				System.out.println(s.name +  "," + s.codename);
			}
		}
		System.out.println();
	}
	
	
	
	public ArrayList<Suspect> getPartners() {
		Partners.sort(Comparator.comparing(Suspect::getName));
		return Partners;
	}



	public void setPartners(ArrayList<Suspect> partners) {
		Partners = partners;
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCodeName() {
		return codename;
	}

	public void setCodeName(String codename) {
		this.codename = codename;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public ArrayList<String> getNumbers() {
		return numbers;
	}

	public void setNumbers(ArrayList<String> numbers) {
		this.numbers = numbers;
	}

	public void addNumber (String number)
	{
		numbers.add(number);
	}
	
	

}
