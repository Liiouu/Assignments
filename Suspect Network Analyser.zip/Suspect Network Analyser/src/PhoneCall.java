
public class PhoneCall extends Communication {
	private int sec;

	public PhoneCall(String num1, String num2, int day, int month, int year, int sec) {
		super(num1, num2, day, month, year);
		this.sec = sec;
	}

	public int getSec() {
		return sec;
	}

	public void setSec(int sec) {
		this.sec = sec;
	}
	
	public void printInfo()
	{
		System.out.println("This phone call has the following info");
		System.out.println("Between " + getNum1() + " --- " + getNum2());
		System.out.println("on " + getYear() + "/" + getMonth() + "/" + getDay());
		System.out.println("Duration: " + sec);
	}
	
		

}
