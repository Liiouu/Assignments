import java.util.ArrayList;

public class Registry {
	private ArrayList<Communication> communications = new ArrayList<>();
	private ArrayList<Suspect> suspects = new ArrayList<>();
	
	
	public void addCommunication(Communication aCommunication)
	{
		communications.add(aCommunication);
		
		Suspect sus1=null, sus2=null;
		for (Suspect sus : suspects)
		{
			if(sus.getNumbers().contains(aCommunication.getNum1()))
			{
				sus1=sus;
			}
			if(sus.getNumbers().contains(aCommunication.getNum2()))
			{
				sus2=sus;
			}
			if(sus1 != null && sus2 != null && !sus1.equals(sus2))
			{
				sus1.addPartner(sus2);
				sus2.addPartner(sus1);
			}
		}
		
	}
	
	public Suspect getSuspectWithMostPartners()
	{
		Suspect topS = suspects.get(0);
		for(Suspect s : suspects)
		{
			if(s.getPartners().size()>topS.getPartners().size())
				topS=s;
		}
		return topS;
	}
	
	public PhoneCall getLongestPhoneCallBetween(String number1, String number2)
	{
		
		PhoneCall longest = null;
		for(Communication com : communications)
		{
			if(com instanceof PhoneCall)
			{
				PhoneCall curr =(PhoneCall) com;
				if((com.getNum1().equals(number1) && com.getNum2().equals(number2)) || (com.getNum1().equals(number2) && com.getNum2().equals(number1)))
				{
					
					if(longest == null || curr.getSec()>longest.getSec())
						longest = curr;
				}
			}
		}
		return longest;
	}
	
	public ArrayList<SMS> getMessagesBetween(String number1, String number2)
	{
		ArrayList<SMS> suspicious = new ArrayList<>();
		for(Communication com : communications)
		{
			if(com instanceof SMS)
			{
				SMS curr = (SMS) com;
				if((com.getNum1().equals(number1) && com.getNum2().equals(number2)) || (com.getNum1().equals(number2) && com.getNum2().equals(number1)))
				{
					if(curr.getText().contains("Bomb") || curr.getText().contains("Attack") || curr.getText().contains("Explosives") || curr.getText().contains("Gun"))
					{
						suspicious.add(curr);
					}
				}
				
			}
		}
		return suspicious;
	}
	
	public void addSuspect( Suspect aSuspect)
	{
		suspects.add(aSuspect);
	}
	
	public ArrayList<Suspect> getSuspect()
	{
		return suspects;
	}
	

}
