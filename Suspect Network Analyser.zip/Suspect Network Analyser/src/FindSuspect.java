import java.awt.event.*;
import javax.swing.*;

import java.util.ArrayList;

public class FindSuspect extends JFrame{
	 
	private JPanel panel;
	private JButton findButton = new JButton("Find"); 
	private JTextField sname = new JTextField("Please enter suspect's name");
	
	Registry registry;

	
	public FindSuspect(Registry registry)
	{
		this.registry = registry;
		panel = new JPanel();

		
		panel.add(sname);
		panel.add(findButton);
		
		this.setContentPane(panel);
		
		ButtonListener listener = new ButtonListener();
		findButton.addActionListener(listener);

		
		this.setSize(400, 400); 
        this.setTitle("Find Suspect"); 
        this.setVisible(true); 
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	class ButtonListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{
			String susName = sname.getText();
			Suspect selectedSuspect = null;
			for(Suspect aSuspect : registry.getSuspect())
			{
				if(aSuspect.getName().equals(susName))
				{
					selectedSuspect = aSuspect;
					break;
				}
			}
			
			if(selectedSuspect!=null)
			{
				
				SuspectPage sp = new SuspectPage(selectedSuspect, registry);
				sp.setLocation(0, 210);
		        FindSuspect.this.dispose();

			}else
				JOptionPane.showMessageDialog(null, "Suspect " + sname.getText() + " Not Found");
		}
		
		
		
	}


}
