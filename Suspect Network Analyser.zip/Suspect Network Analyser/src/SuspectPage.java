import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;


import java.util.ArrayList;

public class SuspectPage extends JFrame{
	private JPanel mainPanel;
	private JPanel panel1;
	private JPanel panel2;
	private JPanel panel3;
	private JPanel panel4;
	private JTextArea nameField;
	private JTextArea codenameField;
	private JTextField numberInput;
	private JButton smsButton = new JButton("Find SMS");
	private JTextArea smsArea;
    private JTextArea suggestedPartnersArea;
    private JButton backButton;
	
	Suspect aSuspect;
	Registry registry;
	
	public SuspectPage(Suspect aSuspect, Registry registry)
	{   
		this.aSuspect = aSuspect;
		this.registry = registry;
		
		//Main Panel
		mainPanel = new JPanel();        
        
        Border sectionBorder = BorderFactory.createLineBorder(Color.GRAY, 1);

		
        //Panel 1 - Suspect Info
		panel1 = new JPanel();
        panel1.setBorder(sectionBorder);

		nameField = new JTextArea();
		nameField.setBorder(sectionBorder);
		nameField.setPreferredSize(new Dimension(110, 19));
		nameField.setText(aSuspect.getName());
		nameField.setEditable(false);

		codenameField = new JTextArea();
		codenameField.setBorder(sectionBorder);
		codenameField.setPreferredSize(new Dimension(110, 19));		
		codenameField.setText(aSuspect.getCodeName());
		codenameField.setEditable(false);
		StringBuilder numbersText = new StringBuilder();
        for (String n : aSuspect.getNumbers()) {
            numbersText.append(n).append("\n");
        }
        JTextArea numbersArea = new JTextArea(numbersText.toString());
        numbersArea.setEditable(false);
        
        panel1.add(nameField);
		panel1.add(codenameField);
        panel1.add(numbersArea);
        
        mainPanel.add(panel1);
        
        //Panel 2 Messages
       panel2 = new JPanel();
       panel2.setBorder(sectionBorder);
       numberInput = new JTextField(15);
       smsArea = new JTextArea(10,22);
       smsArea.setEditable(false);
       smsArea.setBorder(sectionBorder);

       
       panel2.add(numberInput);
       panel2.add(smsArea);
       panel2.add(smsButton);
       
       mainPanel.add(panel2);       
       
       ButtonListener listener = new ButtonListener();
       smsButton.addActionListener(listener);
       
       //Panel 3 -  Partners
       panel3 = new JPanel();
       panel3.setBorder(sectionBorder);
       StringBuilder partnersText = new StringBuilder();
       for (Suspect p : aSuspect.getPartners()) {
    	   String pname = p.getName();
    	   String pcodename = p.getCodeName();
           partnersText.append(pname).append(", ");
           partnersText.append(pcodename).append("\n");
       }
       JTextArea partnersArea = new JTextArea(partnersText.toString());
       partnersArea.setEditable(false);
       partnersArea.setBorder(sectionBorder);
       partnersArea.setPreferredSize(new Dimension(235, 170));

       panel3.add(new JLabel("Partners"));
       panel3.add(partnersArea);
       mainPanel.add(panel3);

		//Panel 4 - Suggested Partners
       panel4 = new JPanel();
       panel4.setBorder(sectionBorder);
       StringBuilder suggestedPartnersText = new StringBuilder();
       for (Suspect s : aSuspect.suggestedPartners()) {
    	   String sname = s.getName();
    	   String scodename = s.getCodeName();
           suggestedPartnersText.append(sname).append(", ");
           suggestedPartnersText.append(scodename).append("\n");
       }
       suggestedPartnersArea = new JTextArea(suggestedPartnersText.toString());
       suggestedPartnersArea.setEditable(false);
       suggestedPartnersArea.setBorder(sectionBorder);
       suggestedPartnersArea.setPreferredSize(new Dimension(230, 80));
       
       panel4.add(new JLabel("Suggested Partners ---->"));
       panel4.add(suggestedPartnersArea);
       mainPanel.add(panel4);
       
       //Back to search screen button
       backButton = new JButton("Back to Search Screen");
       mainPanel.add(backButton);
       
       backButton.addActionListener(listener);

		
		//Setup
		this.setContentPane(mainPanel);
		this.setSize(510, 675); 
        this.setTitle("Suspect Page"); 
        this.setVisible(true); 
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	
	}
	
	class ButtonListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{
			if(e.getSource() == smsButton)
			{
				String number = numberInput.getText();
			    StringBuilder messages = new StringBuilder();
			    for(String n : aSuspect.getNumbers())
			    {
			    	ArrayList<SMS> listOfMessages = registry.getMessagesBetween(number,n);
					for(SMS sms: listOfMessages)
						messages.append(sms.getText()).append("\n");
			    }			    	
			    smsArea.setText(messages.toString());
			}
			else
			{
				new FindSuspect(registry);
				SuspectPage.this.dispose();
			}
		}

	}

}
