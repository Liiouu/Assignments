
public class SMS extends Communication {
	private String text;

	public SMS(String num1, String num2, int day, int month, int year, String text) {
		super(num1, num2, day, month, year);
		this.text = text;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
	public void printInfo()
	{
		System.out.println("This phone sms has the following info");
		System.out.println("Between " + getNum1() + " --- " + getNum2());
		System.out.println("on " + getYear() + "/" + getMonth() + "/" + getDay());
		System.out.println("Text: " + text);
	}

	
}
